

import React from "react";

import Encabezado from "../Componentes/Encabezado";

//2 

function Login() {
    //3
    return (
        <>
            <Encabezado />


        </>
    )
}

//4

export default Login;